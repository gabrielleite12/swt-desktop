
APP_NAME = 'YoutubeMP3App'
COMPANY_NAME = 'Gabrielle Development'
UPDATE_URLS = ['https://raw.githubusercontent.com/gabrielleite12/swt-desktop/main/updates/']
PUBLIC_KEY = 'INSIRA_SUA_CHAVE_PUBLICA_AQUI'
